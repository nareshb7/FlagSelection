import React from 'react'

const MainCompo = () => {
    const mainStyle ={
        width: '500px',
        height: '400px',
        backgroundColor: '#eeeeee',
        margin: '100px',
        borderRadius: '7px'
    }
    function dropDown(){
        <MainCompo/>
    }
  return (
    <div style={mainStyle}>
    <section style={{backgroundColor: '#cccccc',borderRadius:'7px'}}>
      <h3 style={{paddingTop: '10px'}}>Likelihood</h3>
      <select style={{marginLeft: '10px'}}>
      <option onClick={dropDown}>Low</option>
        <option >Medium</option>
        <option>High</option>
        <option>Critical</option>
        <option>Clear</option>
      </select>
    </section>
  </div>
  );
}

export default MainCompo