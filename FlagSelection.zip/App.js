import './App.css'
import MainCompo from './Components/MainCompo';


function App() {
  return (
    <MainCompo/>

  )
}

export default App;
